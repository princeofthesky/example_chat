package model

import (
	"context"
	"fmt"
	"math/rand"
	"system/core/common"
	"system/core/model"
	"system/core/service/systemredis"
	"time"

	"github.com/go-redis/redis/v8"
	"github.com/google/uuid"
)

type UserPublicSubscriptionStorage interface {
	Subscribe()
	Unsubscribe()
	Connect()
	Disconnect()
	SendMessage()
}

type PublicSubscription struct {
	Id               string
	Name             string
	MessageChannel   chan model.Message
	redisClient      *systemredis.RedisClient
	ListeningStatus  bool
	StopListenerChan chan bool
	StopReadingChan  chan bool
	PubSubChannel    *redis.PubSub
}

func NewPublicSubscription(name string, redisClient *systemredis.RedisClient) *PublicSubscription {

	sub := PublicSubscription{
		Id:              uuid.NewString(),
		Name:            name,
		MessageChannel:  make(chan model.Message),
		ListeningStatus: false,
		redisClient:     redisClient,
	}

	return &sub
}

func (sub *PublicSubscription) Disconnect(ctx context.Context) error {
	defer common.Recovery()
	if sub.PubSubChannel != nil {
		if err := sub.PubSubChannel.Unsubscribe(ctx); err != nil {
			return err
		}
		if err := sub.PubSubChannel.Close(); err != nil {
			return err
		}
	}
	close(sub.MessageChannel)
	return nil
}

func (sub *PublicSubscription) Subscribe(ctx context.Context, channel string) error {

	return nil
}

func (sub *PublicSubscription) UnSubscribe(ctx context.Context, channel string) error {

	return nil
}

func (sub *PublicSubscription) SendMessage(msg *model.Message) error {

	return nil
}
func (sub *PublicSubscription) SendMessageWithoutSave(msg *model.Message) error {

	return nil
}

func (sub *PublicSubscription) GetchannelList() ([]string, error) {
	var c []string

	// c1, err := sub.redisClient.GetAllItemFromSet(publish_channel)
	// fmt.Println(c1)
	// if err != nil {
	// 	return nil, err
	// }
	// c = append(c, c1...)
	rand.Seed(time.Now().Unix())
	n := rand.Int() % len(List_public_channel)
	channel := List_public_channel[n]

	c = append(c, channel)
	c2, err := sub.redisClient.GetAllItemFromSet(fmt.Sprintf(user_channel, sub.Name))
	if err != nil {
		return nil, err
	}
	c = append(c, c2...)

	return c, nil
}
