package model

import (
	"context"
	"encoding/json"
	"fmt"
	"system/core/common"
	"system/core/model"
	"system/core/service/systemredis"
	"system/core/sky/provider"
	"system/worker/jobs"

	"time"

	"github.com/go-redis/redis/v8"
	"github.com/google/uuid"
	"github.com/gorilla/websocket"
)

type Subscription struct {
	Id                 string
	name               string
	StopListenerChan   chan bool
	StopReadingChan    chan bool
	MessageReadChannel chan model.Message
	conn               *Connection
	PubSubChannel      *redis.PubSub
	redisClient        *systemredis.RedisClient
	DisconnectChan     chan bool
	ListeningStatus    bool
	ReadingStatus      bool
}

func NewSubscription(name string, ws *websocket.Conn, redisClient *systemredis.RedisClient) *Subscription {
	conn := NewConnection(ws)

	sub := Subscription{
		Id:                 uuid.NewString(),
		name:               name,
		StopListenerChan:   make(chan bool),
		StopReadingChan:    make(chan bool),
		DisconnectChan:     make(chan bool),
		MessageReadChannel: make(chan model.Message),
		conn:               conn,
		ReadingStatus:      false,
		ListeningStatus:    false,
		redisClient:        redisClient,
	}
	conn.ws.SetCloseHandler(func(code int, text string) error {
		if DebugMod {
			fmt.Println("makeconnect", "connection closed id", sub.conn.Id)
		}
		sub.DisconnectChan <- true
		return nil
	})
	c, err := sub.getchannelList()
	if err != nil {
		panic(err)
	}

	fmt.Println("list channel", c)

	if len(c) > 0 {
		pubsub := sub.redisClient.SubscribeChannel(c)
		sub.PubSubChannel = pubsub
		go sub.HandleWriteData()
	}

	return &sub
}

func (sub *Subscription) ReLoadConnection(c []string) {
	// defer common.Recovery()
	fmt.Println("==========reload connection  set up=======")

	if len(c) > 0 {
		pubsub := sub.redisClient.SubscribeChannel(c)
		sub.PubSubChannel = pubsub
		sub.Id = uuid.NewString()
		fmt.Println("start new listener")

		sub.HandleWriteData()
	}
	fmt.Println("==========end reload connection  set up=======")

}

func (sub *Subscription) SubscribeUser(channel string) (bool, error) {
	fmt.Println("==========subscribe start set up=======")
	userChannelsKey := fmt.Sprintf(user_channel, sub.name)
	//debug
	// if sub.redisClient.CheckItemInSet(userChannelsKey, channel) {
	// 	return true, nil
	// }
	if err := sub.redisClient.AddItemToSet(userChannelsKey, channel); err != nil {
		return false, err
	}
	c, err := sub.getchannelList()
	if err != nil {
		panic(err)
	}
	if len(c) > 0 {
		if sub.ListeningStatus {
			sub.StopListenerChan <- true
		}

	}

	fmt.Println("==========end update set up=======")
	sub.ReLoadConnection(c)
	return true, nil
}

func (sub *Subscription) UnsubscribeUser(channel string) (bool, error) {
	userChannelsKey := fmt.Sprintf(user_channel, sub.name)
	if !sub.redisClient.CheckItemInSet(userChannelsKey, channel) {
		return true, nil
	}
	if err := sub.redisClient.RemoveItemToSet(userChannelsKey, channel); err != nil {
		return false, err
	}
	c, err := sub.getchannelList()
	if err != nil {
		panic(err)
	}
	sub.ReLoadConnection(c)
	return true, nil
}

func (sub *Subscription) Disconnect() (bool, error) {
	defer common.Recovery()
	if DebugMod {
		fmt.Println("======StartConnect", "disconnect to ", sub.name, sub.conn.Id)
	}
	go func() {
		defer common.Test("StopListenerChan")
		close(sub.StopListenerChan)

	}()

	go func() {
		defer common.Test("StopReadingChan")
		close(sub.StopReadingChan)

	}()

	if sub.PubSubChannel != nil {
		err := sub.PubSubChannel.Unsubscribe(context.Context(context.TODO()))
		if err != nil {
			panic(err)
		}
		err = sub.PubSubChannel.Close()
		if err != nil {
			panic(err)
		}
	}
	go func() {
		defer common.Recovery()
		close(sub.MessageReadChannel)
		close(sub.DisconnectChan)
	}()

	fmt.Println("==========ok")
	return true, nil
}

func (sub *Subscription) HandleWriteData() {
	conn := sub.conn
	if DebugMod {
		fmt.Println("writePubsub", "starting the listener for sub:", sub.name, sub.Id)
	}
	ticker := time.NewTicker(PingPeriod)
	fmt.Println("===============starting the listener for sub:", sub.name, sub.Id)
	defer func() {
		defer common.Test("HandleWriteData")
		fmt.Println("===============clos pub/sub sub:", sub.Id)
		// sub.PubSubChannel.Close()
		ticker.Stop()

	}()
	fmt.Sprintln("HandleWriteData", sub.PubSubChannel.String())
	sub.ListeningStatus = true
	for {

		select {
		case msg, ok := <-sub.PubSubChannel.Channel():
			if !ok {
				return
			}
			if err := conn.Write(websocket.TextMessage, []byte(msg.Payload)); err != nil {
				if DebugMod {
					fmt.Println("HandleWriteData", err, conn.Id)
				}
				return
			}

		case <-sub.StopListenerChan:
			if DebugMod {
				fmt.Println("writePubsub", "stopping the listener for sub:", sub.name, sub.Id)
			}
			return
		case <-ticker.C:
			fmt.Println("send ping message")
			if err := conn.Write(websocket.PingMessage, []byte{}); err != nil {
				return
			}
		}
	}

}

func (sub *Subscription) ReadData() {

	var debug = true
	var msg model.Message
	conn := sub.conn.GetWs()
	defer func() {
		defer common.Recovery()
		if DebugMod {
			fmt.Println("readData", "send signal stop reading ", sub.Id)
		}
		sub.StopReadingChan <- true
	}()

	conn.SetReadLimit(MaxMessageSize)

	fmt.Println("pong wait", PongWait)

	conn.SetReadDeadline(time.Now().Add(PongWait))
	conn.SetPongHandler(func(string) error { conn.SetReadDeadline(time.Now().Add(PongWait)); return nil })
	for {
		_, item, err := conn.ReadMessage()
		if err != nil {
			// fmt.Println(websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway))
			if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway) {
				var data map[string]interface{}
				json.Unmarshal(item, &data)
				fmt.Println("ReadData func", "error: ", err)
				fmt.Println(data)
			}
			if debug {
				fmt.Println("ReadData func", "error read socket", err.Error())
			}
			break
		} else {
			err = json.Unmarshal(item, &msg)
			if err != nil {
				fmt.Println("ReadData func", "decode messsage error", err)
				continue
			}
			switch msg.Command {
			case commandSubscribe:
				if debug {
					fmt.Println("ReadData func", "read from subscribe", sub.Id)
					fmt.Println("ReadData func", "content", msg.Content)
					fmt.Println("ReadData func", "command", msg.Command)
				}
				if _, err := sub.SubscribeUser(msg.Channel); err != nil {
					fmt.Println(err)
				}
			case commandUnsubscribe:

				if _, err := sub.UnsubscribeUser(msg.Channel); err != nil {
					fmt.Println(err)
				}
			case commandChat:
				if debug {
					fmt.Println("send text")
				}
				if err := sub.sendMessage(&msg); err != nil {
					fmt.Println(err)
				}
			case commandNotify:
				if debug {
					fmt.Println("send text")
				}
				if err := sub.sendMessageWithoutSave(&msg); err != nil {
					fmt.Println(err)
				}
			}
			// limit speed process 10 message/s
			// time.Sleep(100 * time.Millisecond)
		}

	}

}

func (sub *Subscription) getchannelList() ([]string, error) {
	var c []string

	c1, err := sub.redisClient.GetAllItemFromSet(publish_channel)
	if err != nil {
		return nil, err
	}
	c = append(c, c1...)
	c2, err := sub.redisClient.GetAllItemFromSet(fmt.Sprintf(user_channel, sub.name))
	if err != nil {
		return nil, err
	}
	c = append(c, c2...)
	fmt.Println(c)

	return c, nil
}

func (sub *Subscription) sendMessage(msg *model.Message) error {

	loc, _ := time.LoadLocation("UTC")
	now := time.Now().In(loc)
	t := fmt.Sprintf("%d", now.UnixMilli())
	msg.CreatedAt = t
	var data map[string]interface{}
	dataStrim, err := json.Marshal(msg)
	if err != nil {
		fmt.Println(err)
	}
	if DebugMod {
		fmt.Println("SendMessage", msg)
		fmt.Println("SendMessage", "publish message ", msg.Channel, string(dataStrim))
	}
	json.Unmarshal(dataStrim, &data)
	var payload map[string]interface{}
	json.Unmarshal(dataStrim, &payload)
	sub.redisClient.AddItemToStream("room_message_"+msg.Channel, "", data)
	go func(data map[string]interface{}) {
		defer common.Recovery()
		item := provider.Payload{Data: data, Delay: 0}
		ct := context.Background()
		err = jobs.MessageJob.Dispatch(ct, item)
		if err != nil {
			fmt.Println("error send to queue , ", err)
		}
	}(payload)

	return sub.redisClient.PublishMessage(msg.Channel, string(dataStrim))
}

func (sub *Subscription) sendMessageWithoutSave(msg *model.Message) error {

	loc, _ := time.LoadLocation("UTC")
	now := time.Now().In(loc)
	t := fmt.Sprintf("%d", now.UnixMilli())
	msg.CreatedAt = t
	dataStrim, err := json.Marshal(msg)
	if err != nil {
		fmt.Println(err)
	}
	if DebugMod {
		fmt.Println("SendMessage", "publish message ", msg.Channel, string(dataStrim))
	}

	return sub.redisClient.PublishMessage(msg.Channel, string(dataStrim))
}

func (sub *Subscription) GetName() string {
	return sub.name
}

func (sub *Subscription) GetConnection() *Connection {
	return sub.conn
}
