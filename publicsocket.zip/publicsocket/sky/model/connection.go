package model

import (
	"time"

	"github.com/go-redis/redis/v8"
	"github.com/google/uuid"
	"github.com/gorilla/websocket"
)

const (
	// Time allowed to write a message to the peer.
	writeWait = 30 * time.Second
)

type ConnectionStorage interface {
	Write(int, []byte) error
	GetId() string
	GetWs() *websocket.Conn
}

type Connection struct {
	Id   string
	ws   *websocket.Conn
	send chan redis.Message
}

func NewConnection(ws *websocket.Conn) *Connection {
	connect := Connection{
		Id:   uuid.NewString(),
		send: make(chan redis.Message),
		ws:   ws,
	}

	return &connect
}

func (c *Connection) Write(mt int, payload []byte) error {
	// c.mu.Lock()
	// defer c.mu.Unlock()
	c.ws.SetWriteDeadline(time.Now().Add(writeWait))
	return c.ws.WriteMessage(mt, payload)
}
func (c *Connection) GetWs() *websocket.Conn {
	return c.ws
}
func (c *Connection) GetId() string {
	return c.Id
}
