package model

type UserConnection interface {
	Subscribe()
	Unsubscribe()
	Connect()
	Disconnect()
}

type User struct {
}
