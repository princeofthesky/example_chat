package model

import "time"

const (
	commandSubscribe   = "0"
	commandUnsubscribe = "1"
	commandChat        = "2"
	commandNotify      = "3"
	DebugMod           = false
	PongWait           = 20 * time.Second
	MaxMessageSize     = 51200000
	PingPeriod         = (PongWait * 9) / 10
	TrackingUser       = "trackingUser"
)
const (
	publish_channel             = "list_room_available"                // available channel
	user_channel                = "user_channel_%s"                    //user subscribe channel list
	list_user_available         = "list_system_user_available"         // list available user
	list_conversation_available = "list_system_conversation_available" // list available conversation
	conversation_mesage         = "conversation_message_%s"
)

var List_public_channel = []string{
	"public1",
	"public2",
	"public3",
	"public4",
	"public5",
	"public6",
	"public7",
	"public8",
	"public9",
	"public10",
	"public11",
	"public12",
	"public13",
	"public14",
	"public15",
	"public16",
	"public17",
	"public18",
	"public19",
	"public20",
	"public21",
	"public22",
	"public23",
	"public24",
	"public25",
	"public26",
	"public27",
	"public28",
	"public29",
	"public30",
	"public31",
	"public32",
	"public33",
	"public34",
	"public35",
	"public36",
	"public37",
	"public38",
	"public39",
	"public40",
	"public41",
	"public42",
	"public43",
	"public44",
	"public45",
	"public46",
	"public47",
	"public48",
	"public49",
	"public50",
	"public51",
	"public52",
	"public53",
	"public54",
	"public55",
	"public56",
	"public57",
	"public58",
	"public59",
	"public60",
	"public61",
	"public62",
	"public63",
	"public64",
	"public65",
	"public66",
	"public67",
	"public68",
	"public69",
	"public70",
}
