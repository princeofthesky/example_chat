package model

import (
	"context"
	"encoding/json"
	"fmt"
	"math/rand"
	"strings"
	"system/core/common"
	"system/core/model"
	"system/core/service/systemredis"
	"system/core/sky/provider"
	"system/worker/jobs"

	"time"

	"github.com/go-redis/redis/v8"
	"github.com/google/uuid"
)

const (
	public_channel = "public_channel_skyx"
)

type UserSubscriptionStorage interface {
	Subscribe()
	Unsubscribe()
	Connect()
	Disconnect()
	SendMessage()
}

type UserSubscription struct {
	Id               string
	Name             string
	MessageChannel   chan model.Message
	PubSubChannel    *redis.PubSub
	redisClient      *systemredis.RedisClient
	ListeningStatus  bool
	StopListenerChan chan bool
	StopReadingChan  chan bool
}

func NewUserSubscription(name string, redisClient *systemredis.RedisClient) *UserSubscription {

	sub := UserSubscription{
		Id:               uuid.NewString(),
		Name:             name,
		StopListenerChan: make(chan bool),
		MessageChannel:   make(chan model.Message),
		ListeningStatus:  false,
		redisClient:      redisClient,
		StopReadingChan:  make(chan bool),
	}

	return &sub
}

func (sub *UserSubscription) Initialization(ctx context.Context) error {
	defer common.Recovery()
	fmt.Println("start initialize")
	c, err := sub.getchannelList()
	if err != nil {
		panic(err)
	}
	if sub.PubSubChannel != nil {
		if err := sub.PubSubChannel.Unsubscribe(ctx); err != nil {
			return err
		}
		if err := sub.PubSubChannel.Close(); err != nil {
			return err
		}
	}
	// fmt.Println("listen status", sub.ListeningStatus)
	if sub.ListeningStatus {
		sub.StopListenerChan <- true

	}
	fmt.Println("total channel", c)
	return sub.doConnect(c)
}

func (sub *UserSubscription) Disconnect(ctx context.Context) error {
	defer common.Recovery()
	if strings.HasPrefix(sub.Name, "skyx") {
		fmt.Println("Disconection for ", sub.Name)
	}
	if sub.PubSubChannel != nil {

		// fmt.Println("clonse subscription ", sub.Id)
		if err := sub.PubSubChannel.Unsubscribe(ctx); err != nil {
			return nil
		}
		if err := sub.PubSubChannel.Close(); err != nil {
			return err
		}
	}
	// fmt.Println("clonse channel ", sub.Id)
	close(sub.MessageChannel)
	return nil
}

func (sub *UserSubscription) Subscribe(ctx context.Context, channel string) error {

	userChannelsKey := fmt.Sprintf(user_channel, sub.Name)
	//debug
	if sub.redisClient.CheckItemInSet(userChannelsKey, channel) {
		return nil
	}
	if err := sub.redisClient.AddItemToSet(userChannelsKey, channel); err != nil {
		return err
	}
	fmt.Println("subscribe okay ", userChannelsKey, channel)

	return sub.Initialization(ctx)
}

func (sub *UserSubscription) UnSubscribe(ctx context.Context, channel string) error {

	userChannelsKey := fmt.Sprintf(user_channel, sub.Name)
	//debug
	if !sub.redisClient.CheckItemInSet(userChannelsKey, channel) {
		return nil
	}
	if err := sub.redisClient.RemoveItemToSet(userChannelsKey, channel); err != nil {
		return err
	}

	return sub.Initialization(ctx)
}

func (sub *UserSubscription) SendMessage(msg *model.Message) error {

	loc, _ := time.LoadLocation("UTC")
	now := time.Now().In(loc)
	t := fmt.Sprintf("%d", now.UnixMilli())
	msg.CreatedAt = t
	dataStrim, err := json.Marshal(msg)
	if err != nil {
		fmt.Println(err)
	}
	return sub.redisClient.PublishMessage(msg.Channel, string(dataStrim))
}

func (sub *UserSubscription) SendMessageCmd(msg *model.Message) error {
	defer common.Recovery()
	loc, _ := time.LoadLocation("UTC")
	now := time.Now().In(loc)
	t := fmt.Sprintf("%d", now.UnixMilli())
	msg.CreatedAt = t
	dataStrim, err := json.Marshal(msg)
	if err != nil {
		fmt.Println(err)
	}

	go func(msg *model.Message) {
		defer common.Recovery()
		var payload map[string]interface{}
		json.Unmarshal(dataStrim, &payload)
		sub.redisClient.AddItemToStream("room_message_"+msg.Channel, "", payload)
		item := provider.Payload{Data: payload, Delay: 0}
		ct := context.Background()
		err = jobs.MessageJob.Dispatch(ct, item)
		if err != nil {
			fmt.Println("error send to queue , ", err)
		}
	}(msg)

	return sub.redisClient.PublishMessage(msg.Channel, string(dataStrim))
}

func (sub *UserSubscription) SendMessageWithoutSave(msg *model.Message) error {
	defer common.Recovery()

	loc, _ := time.LoadLocation("UTC")
	now := time.Now().In(loc)
	t := fmt.Sprintf("%d", now.UnixMilli())
	msg.CreatedAt = t
	dataStrim, err := json.Marshal(msg)
	if err != nil {
		fmt.Println(err)
	}
	if DebugMod {
		fmt.Println("SendMessage", "publish message ", msg.Channel, string(dataStrim))
	}

	return sub.redisClient.PublishMessage(msg.Channel, string(dataStrim))
}

func (sub *UserSubscription) doConnect(c []string) error {
	defer common.Recovery()
	pubsub := sub.redisClient.SubscribeChannel(c)
	sub.PubSubChannel = pubsub

	go func() {
		defer func() {
			fmt.Print("close listen")
			common.Recovery()
		}()
		sub.ListeningStatus = true
		for {
			select {
			case msg, ok := <-pubsub.Channel():
				if !ok {
					return
				}
				var m model.Message
				err := json.Unmarshal([]byte(msg.Payload), &m)
				if err == nil {
					sub.MessageChannel <- m
				} else {
					fmt.Println(err)

				}
			case <-sub.StopListenerChan:
				fmt.Println("stopping the listener for user:")
				return

			}

		}
	}()
	return nil
}
func (sub *UserSubscription) getchannelList() ([]string, error) {
	var c []string

	// c1, err := sub.redisClient.GetAllItemFromSet(publish_channel)
	// fmt.Println(c1)
	// if err != nil {
	// 	return nil, err
	// }
	// c = append(c, c1...)
	c = append(c, public_channel)
	rand.Seed(time.Now().Unix())
	n := rand.Int() % len(List_public_channel)
	channel := List_public_channel[n]

	c = append(c, channel)
	c2, err := sub.redisClient.GetAllItemFromSet(fmt.Sprintf(user_channel, sub.Name))
	if err != nil {
		return nil, err
	}
	c = append(c, c2...)

	return c, nil
}
