package repository

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"system/core/common"
	core_model "system/core/model"
	"system/websocket/sky/model"
	"time"

	"github.com/go-redis/redis/v8"
	"github.com/gorilla/websocket"
)

func (sk *SocketSky) TestPublish() {
	m := core_model.Message{Channel: "public_channel_skyx", Content: "test message", Command: "4"}
	fmt.Println("send message to public channel ", m)
	sk.PublicMessageChannel <- m
	for _, v := range model.List_public_channel {
		m := core_model.Message{Channel: v, Content: "test message" + v, Command: "4"}
		fmt.Println("send message to public channel ", m)
	}
}

func (sk *SocketSky) CreateConnectionPublic(username string, ws *websocket.Conn) (bool, error) {
	if !strings.HasPrefix(username, "skyx") {
		defer common.Test("CreateConnectionPublic")
	}
	conn := model.NewConnection(ws)
	sub := model.NewPublicSubscription(username, sk.redis)

	c, _ := sub.GetchannelList()
	fmt.Println("test sub channel", c)
	pubsub := sk.redis.SubscribeChannel(c)
	sub.PubSubChannel = pubsub

	sk.SubscriptionPulblic[username] = sub

	fmt.Println("==========total public=======", len(sk.SubscriptionPulblic))

	conn.GetWs().SetCloseHandler(func(code int, text string) error {
		if strings.HasPrefix(username, "skyx") {
			fmt.Println("start close handle for from public subscrition", username)
		}
		sub := sk.SubscriptionPulblic[username]
		if err := sub.Disconnect(context.Context(context.TODO())); err != nil {
			return err
		}
		if strings.HasPrefix(username, "skyx") {
			fmt.Println("remove from public subscrition", username)
		}
		delete(sk.SubscriptionPulblic, username)
		if strings.HasPrefix(username, "skyx") {
			fmt.Println("close connection", username)
		}
		return nil
	})
	go HandleWriteDataPublic(sub, conn)
	go ReadDataPublic(conn, username)
	//try test
	// prCh := pubsub.Channel()
	// go listenPrivateMessageTest(prCh, sk.PublicMessageChannel)

	return true, nil
}
func listenBroadcastMessage(ch <-chan *redis.Message, message chan core_model.Message) {
	defer func() {
		common.Test("listenBroadcastMessage listen")
		fmt.Println("complete read")
	}()

	for {
		select {
		case msg, ok := <-ch:
			if !ok {
				return
			}
			fmt.Println("send message to public channel ", msg)
			var m core_model.Message
			err := json.Unmarshal([]byte(msg.Payload), &m)
			if err == nil {
				fmt.Println("send message to public channel ", m)
				message <- m
			} else {
				fmt.Println(err)
			}

		}
	}

}

// func listenPrivateMessageTest(ch <-chan *redis.Message, message chan core_model.Message) {
// 	defer func() {
// 		common.Test("listenBroadcastMessage listen")
// 		fmt.Println("complete read")
// 	}()

// 	for {
// 		select {
// 		case msg, ok := <-ch:
// 			if !ok {
// 				return
// 			}
// 			fmt.Println("send message to public channel ", msg)
// 			var m core_model.Message
// 			err := json.Unmarshal([]byte(msg.Payload), &m)
// 			if err == nil {
// 				fmt.Println("send message to public channel ", m)
// 				message <- m
// 			} else {
// 				fmt.Println(err)
// 			}

// 		}
// 	}

// }

func writePublicMessage(sk *SocketSky) {
	defer func() {
		common.Test("ListenPublicMessage")
		fmt.Println("complete write")
	}()
	fmt.Println("===========listen from public============")

	for {
		select {
		case msg, ok := <-sk.PublicMessageChannel:
			if !ok {
				fmt.Println("receive message error")
				return
			}
			fmt.Println("send public message to  channel", msg)
			for _, v := range sk.SubscriptionPulblic {

				go func(v *model.PublicSubscription, msg *core_model.Message) {
					if strings.HasPrefix(v.Name, "skyx") {
						fmt.Println("send message to subcription channel", v.Name)
					}
					v.MessageChannel <- *msg
					if strings.HasPrefix(v.Name, "skyx") {
						fmt.Println("send message to subcription channel done")
					}
				}(v, &msg)
			}
		}

	}

}

func ReadDataPublic(conn *model.Connection, username string) {
	if strings.HasPrefix(username, "skyx") {
		fmt.Println("ReadDataPublic", "start handle reading from client", username)
	}

	con := conn.GetWs()
	defer func() {
		defer common.Recovery()
		if strings.HasPrefix(username, "skyx") {
			fmt.Println("readData", "send signal stop reading ", username)
		}
		con.Close()
	}()

	con.SetReadLimit(MaxMessageSize)

	// fmt.Println("pong wait", PongWait)

	// con.SetReadDeadline(time.Now().Add(PongWait))
	// con.SetPongHandler(func(string) error { con.SetReadDeadline(time.Now().Add(PongWait)); return nil })
	for {
		_, item, err := con.ReadMessage()
		if err != nil {
			// fmt.Println(websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway))
			if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway) {
				var data map[string]interface{}
				json.Unmarshal(item, &data)
			}
			if strings.HasPrefix(username, "skyx") {
				fmt.Println("read data fron client  fail", username, err.Error())
			}
			break
		}
	}
}

func HandleWriteDataPublic(sub *model.PublicSubscription, conn model.ConnectionStorage) {
	// defer common.Test("HandleWriteDataPublic")
	ticker := time.NewTicker(PingPeriod)
	defer func() {
		defer common.Test("HandleWriteData")
		if strings.HasPrefix(sub.Name, "skyx") {
			fmt.Println("===============close pub/sub ", sub.Name, sub.Id)
		}

		// sub.PubSubChannel.Close()
		ticker.Stop()

	}()
	for {
		select {
		case msg, ok := <-sub.MessageChannel:
			if !ok {
				return
			}
			if strings.HasPrefix(sub.Name, "skyx") {
				fmt.Println("==========receive message from messsage channel =======", sub.Name, msg)
			}

			if data, err := json.Marshal(msg); err == nil {
				if err := conn.Write(websocket.TextMessage, data); err != nil {
					if strings.HasPrefix(sub.Name, "skyx") {
						fmt.Println("write messafe to channel error ", sub.Name, err.Error())
					}
					return
				} else {
					if strings.HasPrefix(sub.Name, "skyx") {
						fmt.Println("write message to channel success ", sub.Name)
					}
				}
			}

		case <-ticker.C:
			if strings.HasPrefix(sub.Name, "skyx") {
				fmt.Println("send ping message ", sub.Name)
			}
			if err := conn.Write(websocket.PingMessage, []byte{}); err != nil {
				return
			}

		}
	}
}
