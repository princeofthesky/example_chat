package repository

import (
	"fmt"
	"system/core/common"
	"system/core/service/systemredis"
	"system/websocket/sky/model"

	"github.com/gorilla/websocket"
	"go.mongodb.org/mongo-driver/mongo"
)

const (
	DebugMod = true
)

type socketSky struct {
	redis          *systemredis.RedisClient
	db             *mongo.Client
	Subscription   map[string]*model.Subscription
	connectchan    chan *model.Subscription
	disconnectchan chan *model.Subscription
	resconnectchan chan *model.Subscription
	closeChn       chan bool
}

func NewSocketSky(client *systemredis.RedisClient, db *mongo.Client) *socketSky {
	var socket = socketSky{
		redis:          client,
		db:             db,
		Subscription:   make(map[string]*model.Subscription),
		connectchan:    make(chan *model.Subscription),
		disconnectchan: make(chan *model.Subscription),
		resconnectchan: make(chan *model.Subscription),
		closeChn:       make(chan bool),
	}
	return &socket
}
func (sk *socketSky) CreateConnection(username string, conn *websocket.Conn) (bool, error) {
	defer common.Recovery()
	originSub, ok := sk.Subscription[username]
	if ok {
		if originSub.ListeningStatus {
			originSub.StopListenerChan <- true
		}
		if originSub.ReadingStatus {
			originSub.StopReadingChan <- true
		}

		delete(sk.Subscription, username)
	}
	go sk.SetUpConnection(username, conn)
	return true, nil
}
func (sk *socketSky) SetUpConnection(username string, conn *websocket.Conn) {
	defer common.Recovery()
	fmt.Println("==========start set up connection =======")
	sub := model.NewSubscription(username, conn, sk.redis)

	go func(sub *model.Subscription) {
		defer common.Recovery()

		defer func() {
			sub.Disconnect()
			delete(sk.Subscription, username)
			fmt.Println("==========total=======", len(sk.Subscription))
		}()
		go sub.ReadData()
		for {
			select {
			case <-sub.DisconnectChan:
				return
			}
		}

	}(sub)

	sk.Subscription[username] = sub
	fmt.Println("==========total=======", len(sk.Subscription))
	fmt.Println(sub.Id)
	fmt.Println("==========complete set up=======")
}
func (sk *socketSky) CloseConnection(sub *model.Subscription) {
	defer common.Recovery()

	err := sub.GetConnection().GetWs().Close()
	if err != nil {
		panic(err)
	}
	fmt.Println("==========")
}
func (sk *socketSky) Subscribe(username string, channel string) (bool, error) {
	var debug = false
	fmt.Println("==========subscribe set up=======")
	if debug {
		fmt.Println("Subscribe", username, channel)
	}

	sub, ok := sk.Subscription[username]
	if !ok {
		if debug {
			fmt.Println("Subscribe", "username in valid", username)
		}
		return false, nil
	}
	if debug {
		fmt.Println("Subscribe", "channel", channel)
	}
	_, err := sub.SubscribeUser(channel)
	if err == nil {
		go sk.SetUpConnection(username, sub.GetConnection().GetWs())
	}

	return true, err
}

func (sk *socketSky) Unsubscribe(username string, channel string) (bool, error) {

	sub, ok := sk.Subscription[username]
	if !ok {
		return false, nil
	}
	return sub.UnsubscribeUser(channel)
}

func (sk *socketSky) Debug(username string, channel string) {
	userChannelsKey := fmt.Sprintf("user_channel_%s", channel)
	sk.redis.AddItemToSet(userChannelsKey, channel)

}

func (sk *socketSky) CreateConnectionPublic(username string, ws *websocket.Conn) (bool, error) {
	return false, nil
}
