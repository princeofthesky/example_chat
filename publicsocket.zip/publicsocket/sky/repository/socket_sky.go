package repository

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"strconv"
	"strings"
	"system/core/common"
	core_model "system/core/model"
	"system/core/service/systemredis"
	"system/websocket/sky/model"
	"time"

	"github.com/go-redis/redis/v8"
	"github.com/gorilla/websocket"
	"go.mongodb.org/mongo-driver/mongo"
)

const (
	public_channel = "public_channel_skyx"
)

const (
	commandSubscribe    = "0"
	commandUnsubscribe  = "1"
	commandChat         = "2"
	commandNotify       = "3"
	commandNotifyPublic = "4"
	PongWait            = 30 * time.Second
	MaxMessageSize      = 51200000
	PingPeriod          = (PongWait * 9) / 10
)
const (
	publish_channel             = "list_room_available"                // available channel
	user_channel                = "user_channel_%s"                    //user subscribe channel list
	list_user_available         = "list_system_user_available"         // list available user
	list_conversation_available = "list_system_conversation_available" // list available conversation
	conversation_mesage         = "conversation_message_%s"
)

type SocketSky struct {
	redis                *systemredis.RedisClient
	db                   *mongo.Client
	Subscription         map[string]*model.UserSubscription
	PublicSub            *redis.PubSub
	SubscriptionPulblic  map[string]*model.PublicSubscription
	PublicMessageChannel chan core_model.Message
	stopListenerChan     chan struct{}
}

func NewSky(client *systemredis.RedisClient, db *mongo.Client) *SocketSky {

	var socket = SocketSky{
		redis:                client,
		db:                   db,
		Subscription:         make(map[string]*model.UserSubscription),
		SubscriptionPulblic:  make(map[string]*model.PublicSubscription),
		PublicMessageChannel: make(chan core_model.Message),
		stopListenerChan:     make(chan struct{}),
	}
	c, err := socket.getPublicChannelList()
	if err != nil {
		panic(err)
	}

	pubsub := socket.redis.SubscribeChannel(c)

	socket.PublicSub = pubsub

	return &socket
}
func (sk *SocketSky) Initialization() {
	ch := sk.PublicSub.Channel()
	go listenBroadcastMessage(ch, sk.PublicMessageChannel)
	go writePublicMessage(sk)

}

func (sk *SocketSky) Validate(username string) error {
	var limit = 100
	limit, err := strconv.Atoi(os.Getenv("APP_LIMIT_CONNECT"))
	if err != nil {
		limit = 100
	}
	if len(sk.SubscriptionPulblic) >= limit {
		return errors.New("limit connectiontion " + strconv.Itoa(limit))
	}
	return nil
}

func (sk *SocketSky) CreateConnection(username string, ws *websocket.Conn) (bool, error) {
	defer common.Recovery()
	conn := model.NewConnection(ws)
	ctx := context.Context(context.TODO())
	sub := model.NewUserSubscription(username, sk.redis)
	err := sub.Initialization(ctx)
	if err != nil {
		panic(err)
	}
	sk.Subscription[username] = sub

	conn.GetWs().SetCloseHandler(func(code int, text string) error {
		fmt.Println("connection closed for user", username)

		u, ok := sk.Subscription[username]
		if ok && u != nil {
			fmt.Println(u.Id)
			if err := u.Disconnect(context.Context(context.TODO())); err != nil {
				return err
			}
			delete(sk.Subscription, username)
			close(u.StopReadingChan)
		}

		return nil
	})
	go HandleWriteData(sub, conn)

	go HandleReadData(sub, conn)

	return true, nil
}

func HandleWriteData(sub *model.UserSubscription, conn *model.Connection) {

	defer common.Test("write socket channel")
	// for msg := range sub.MessageChannel {
	// 	if data, err := json.Marshal(msg); err == nil {
	// 		if err := conn.Write(websocket.TextMessage, data); err != nil {
	// 			fmt.Println("HandleWriteData", err, conn.GetId())
	// 			return
	// 		}
	// 	}
	// }

	ticker := time.NewTicker(PingPeriod)
	defer func() {
		defer common.Test("HandleWriteData")
		if strings.HasPrefix(sub.Name, "skyx") {
			fmt.Println("===============close pub/sub ", sub.Name, sub.Id)
		}
		ticker.Stop()

	}()
	for {
		select {
		case msg, ok := <-sub.MessageChannel:
			if !ok {
				return
			}
			if strings.HasPrefix(sub.Name, "skyx") {
				fmt.Println("==========receive message from messsage channel =======", sub.Name, msg)
			}

			if data, err := json.Marshal(msg); err == nil {
				if err := conn.Write(websocket.TextMessage, data); err != nil {
					if strings.HasPrefix(sub.Name, "skyx") {
						fmt.Println("write messafe to channel error ", sub.Name, err.Error())
					}
					return
				} else {
					if strings.HasPrefix(sub.Name, "skyx") {
						fmt.Println("write message to channel success ", sub.Name)
					}
				}
			}

		case <-ticker.C:
			if strings.HasPrefix(sub.Name, "skyx") {
				fmt.Println("send ping message ", sub.Name)
			}
			if err := conn.Write(websocket.PingMessage, []byte{}); err != nil {
				return
			}

		}
	}

}

func HandleReadData(sub *model.UserSubscription, conn *model.Connection) {
	defer func() {
		common.Recovery()
		conn.GetWs().Close()
	}()
	var msg core_model.Message
	con := conn.GetWs()
	for {

		_, item, err := con.ReadMessage()
		if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway) {
			var data map[string]interface{}
			json.Unmarshal(item, &data)
			fmt.Println("ReadData func", "error: ", err)
			fmt.Println(data)
			return
		}
		if err != nil {
			fmt.Println("ReadData func", "error read socket", err.Error())
			return
		}
		err = json.Unmarshal(item, &msg)
		if err != nil {
			fmt.Println("ReadData func", "parse json error", err.Error())
			return
		}
		ctx := context.Context(context.TODO())
		switch msg.Command {
		case commandSubscribe:
			if err := sub.Subscribe(ctx, msg.Channel); err != nil {
				fmt.Println(err)
			}
		case commandUnsubscribe:

			if err := sub.UnSubscribe(ctx, msg.Channel); err != nil {
				fmt.Println(err)
			}
		case commandChat:
			if err := sub.SendMessageCmd(&msg); err != nil {
				fmt.Println(err)
			}
		case commandNotify:
			if err := sub.SendMessageWithoutSave(&msg); err != nil {
				fmt.Println(err)
			}
		case commandNotifyPublic:
			if err := sub.SendMessageWithoutSave(&msg); err != nil {
				fmt.Println(err)
			}

		}

	}

}

func (sk *SocketSky) Subscribe(username string, channel string) (bool, error) {

	return true, nil
}

func (sk *SocketSky) Unsubscribe(username string, channel string) (bool, error) {

	return true, nil
}

func (sub *SocketSky) getPublicChannelList() ([]string, error) {
	var c []string

	// c1, err := sub.redisClient.GetAllItemFromSet(publish_channel)
	// if err != nil {
	// 	return nil, err
	// }
	// c = append(c, c1...)

	c = append(c, public_channel)

	return c, nil
}

func (sk *SocketSky) Debug(username string, channel string) {
	userChannelsKey := fmt.Sprintf("user_channel_%s", channel)
	sk.redis.AddItemToSet(userChannelsKey, channel)

}
