package transport

import (
	"fmt"
	"net/http"
	"system/websocket/sky/biz"

	"github.com/gin-gonic/gin"
)

func (hdl *skyHandler) OpenConnectionPublic(c *gin.Context) {

	biz := biz.NewUserConnection(hdl.repo)
	username := c.Param("id")
	_, err := biz.ConnectPublic(c.Writer, c.Request, username)
	if err != nil {
		fmt.Println(err)
		c.JSON(http.StatusBadGateway, gin.H{
			"code":    http.StatusBadGateway,
			"message": err.Error(),
		})

	}
}

func (hdl *skyHandler) TestPublish(c *gin.Context) {

	biz := biz.NewUserConnection(hdl.repo)
	biz.TestPublish()
	c.JSON(http.StatusOK, gin.H{
		"code":    http.StatusOK,
		"message": "",
	})

}
