package biz

import (
	"fmt"
	"net/http"
	"strings"

	"github.com/gorilla/websocket"
)

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
}

type user struct {
	repo SubscriptionStorage
}

func NewUserConnection(repo SubscriptionStorage) *user {
	return &user{repo: repo}
}

func (u *user) Connect(w http.ResponseWriter, r *http.Request, username string) (bool, error) {

	upgrader.CheckOrigin = func(r *http.Request) bool { return true }
	ws, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		return false, nil
	}
	return u.repo.CreateConnection(username, ws)
}

func (u *user) ConnectPublic(w http.ResponseWriter, r *http.Request, username string) (bool, error) {
	if !strings.HasPrefix(username, "skyx") {
		if err := u.repo.Validate(username); err != nil {
			return false, err
		}
	} else {
		fmt.Println("sea ca priority")
	}

	upgrader.CheckOrigin = func(r *http.Request) bool { return true }
	ws, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		return false, nil
	}
	// return u.repo.CreateConnection(username, ws)
	return u.repo.CreateConnectionPublic(username, ws)
}

func (u *user) TestPublish() {
	fmt.Println("run debug")
	u.repo.TestPublish()
}
